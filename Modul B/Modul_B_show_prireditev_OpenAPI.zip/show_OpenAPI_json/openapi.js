var spec = {
  "openapi": "3.0.1",
  "info": {
    "title": "Modul B - prireditev OpenAPI 3.0 ",
    "version": "0.1.0"
  },
  "servers": [
    {
      "url": "https://localhost/api/v3"
    }
  ],
  "tags": [
  ],
  "paths": {
    "/auth": {
      "post": {
        "summary": "avtentificira uporabnika, vrne JWT (token))",
        "operationId": "authUser",
        "requestBody": {
          "description": "login ?",
          "content": {
            "application/json": {
              "schema": {
                "$ref": "#/components/schemas/AuthData"
              }
            }
          }
        },
        "responses": {
          "default": {
            "description": "opracija uspešna, vrne JWT (token)",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/Token"
                }
              }
            }
          }
        }
      }
    },
    "/dogodek": {
      "get": {
        "summary": "Predstavi seznam aktivnih dogodkov z njihovimi ID-ji",
        "operationId": "getDogodek",
        "responses": {
          "200": {
            "description": "OK",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/DogodekSeznamResponse"
                }
              }
            }
          }
        }
      }
    },
    "/dogodek/{id}": {
      "get": {
        "summary": "Podrobnosti specifičnega dogodka",
        "operationId": "getDogodekById",
        "parameters": [
          {
            "name": "id",
            "in": "path",
            "description": "ID of the Dogodek to fetch",
            "required": true,
            "schema": {
              "type": "integer"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/Dogodek"
                }
              }
            }
          }
        }
      }
    },
    "/user": {
      "get": {
        "summary": "Vrne seznam vseh porabnikov/prodajalcev",
        "operationId": "getUsers",
        "responses": {
          "200": {
            "description": "OK",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/UserResponse"
                }
              }
            }
          }
        }
      },
      "put": {
        "security": [
          {
            "bearerAuth": []
          }
        ],
        "summary": "Ažurira (spremeni) geslo obstoječega User",
        "operationId": "changePasswordOfUser",
        "requestBody": {
          "description": "An array of new Vstopnica records",
          "content": {
            "*/*": {
              "schema": {
                "$ref": "#/components/schemas/UserPassword"
              }
            }
          },
          "required": true
        },
        "responses": {
          "200": {
            "description": "OK",
            "content": {}
          },
          "400": {
            "description": "Invalid input",
            "content": {}
          }
        }
      }
    },
    "/vstopnica": {
      "post": {
        "security": [
          {
            "bearerAuth": []
          }
        ],
        "summary": "Kreira/Proda novo Vstopnica",
        "operationId": "createVstopnica",
        "requestBody": {
          "description": "An array of new Vstopnica records",
          "content": {
            "*/*": {
              "schema": {
                "$ref": "#/components/schemas/VstopnicaNova"
              }
            }
          },
          "required": true
        },
        "responses": {
          "201": {
            "description": "Ustvarjena",
            "content": {}
          },
          "400": {
            "description": "Napačen vnos, vstopnica ni kreirana",
            "content": {}
          }
        },
        "x-codegen-request-body-name": "vstopnicaRequest"
      }
    },
    "/vstopnica/{Serijskast}": {
      "get": {
        "security": [
          {
            "bearerAuth": []
          }
        ],
        "summary": "preveri Vstopnica po serijski stevilki",
        "operationId": "getVstopnicaBySerijskaSt",
        "parameters": [
          {
            "name": "Serijskast",
            "in": "path",
            "description": "ID of the Vstopnica to fetch",
            "required": true,
            "schema": {
              "type": "integer"
            }
          }
        ],
        "responses": {
          "200": {
            "description": "OK",
            "content": {
              "application/json": {
                "schema": {
                  "$ref": "#/components/schemas/VstopnicaKontrola"
                }
              }
            }
          }
        }
      }
    }
  },
  "components": {
    "schemas": {
      "AuthData": {
        "type": "object",
        "properties": {
          "UserEmail": {
            "type": "string"
          },
          "Password": {
            "type": "string"
          }
        }
      },
      "Token": {
        "type": "object",
        "properties": {
          "jwt": {
            "type": "string"
          }
        }
      },
      "Cena": {
        "type": "object",
        "properties": {
          "ID": {
            "type": "integer"
          },
          "DogodekId": {
            "type": "integer"
          },
          "VrstaodsekId": {
            "type": "integer"
          },
          "Znesek": {
            "type": "number",
            "nullable": true
          }
        }
      },
      "Dogodek": {
        "type": "object",
        "properties": {
          "ID": {
            "type": "integer"
          },
          "Naziv": {
            "type": "string"
          },
          "Naslov": {
            "type": "string",
            "nullable": true
          },
          "Tel": {
            "type": "string",
            "nullable": true
          },
          "URL": {
            "type": "string",
            "nullable": true
          },
          "Email": {
            "type": "string",
            "nullable": true
          },
          "Datumura": {
            "type": "string"
          },
          "Zakljucek": {
            "type": "string",
            "nullable": true
          }
        }
      },
      "DogodekElement": {
        "type": "object",
        "properties": {
          "dogodekID": {
            "type": "integer"
          },
          "dogodekNaziv": {
            "type": "string"
          },
          "dogodekDatumUra": {
            "type": "string"
          }
        }
      },
      "DogodekSeznamResponse": {
        "type": "object",
        "properties": {
          "Data": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/DogodekElement"
            }
          }
        }
      },
      "DogodekResponse": {
        "type": "object",
        "properties": {
          "Data": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/Dogodek"
            }
          }
        },
        "description": "An array of Dogodek objects"
      },
      "Stranka": {
        "type": "object",
        "properties": {
          "ID": {
            "type": "integer"
          },
          "Ime": {
            "type": "string"
          },
          "Priimek": {
            "type": "string"
          },
          "Email": {
            "type": "string",
            "nullable": true
          },
          "Davcnast": {
            "type": "integer"
          },
          "Ustvarjena": {
            "type": "string"
          },
          "Azurirana": {
            "type": "string",
            "nullable": true
          },
          "Status": {
            "type": "integer"
          },
          "Secret": {
            "type": "string",
            "nullable": true
          }
        }
      },
      "StrankaVnos": {
        "type": "object",
        "properties": {
          "Ime": {
            "type": "string"
          },
          "Priimek": {
            "type": "string"
          },
          "Davcnast": {
            "type": "integer"
          },
          "Email": {
            "type": "string",
            "nullable": true
          }
        }
      },
      "User": {
        "type": "object",
        "properties": {
          "ID": {
            "type": "integer"
          },
          "Email": {
            "type": "string"
          },
          "Password": {
            "type": "string",
            "nullable": true
          },
          "Name": {
            "type": "string",
            "nullable": true
          },
          "Level": {
            "type": "integer",
            "nullable": true
          },
          "Status": {
            "type": "integer",
            "nullable": true
          },
          "CreatedAt": {
            "type": "string",
            "nullable": true
          },
          "UpDatedAt": {
            "type": "string",
            "nullable": true
          }
        }
      },
      "UserRequest": {
        "type": "object",
        "properties": {
          "Data": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/User"
            }
          }
        },
        "description": "An array of User objects"
      },
      "UserResponse": {
        "type": "object",
        "properties": {
          "Data": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/User"
            }
          }
        },
        "description": "An array of User objects"
      },
      "UserPassword": {
        "type": "object",
        "properties": {
          "Username": {
            "type": "string"
          },
          "OldPassword": {
            "type": "string"
          },
          "NewPassword": {
            "type": "string"
          }
        }
      },
      "Vstopnica": {
        "type": "object",
        "properties": {
          "ID": {
            "type": "integer"
          },
          "Serijskast": {
            "type": "number",
            "nullable": true
          },
          "DogodekId": {
            "type": "integer"
          },
          "StrankaId": {
            "type": "integer"
          },
          "CenaId": {
            "type": "integer"
          },
          "Prodana": {
            "type": "string"
          },
          "ProdajalecId": {
            "type": "integer",
            "nullable": true
          }
        }
      },
      "VstopnicaKontrola": {
        "type": "object",
        "properties": {
          "ID": {
            "type": "integer"
          },
          "Serijskast": {
            "type": "number"
          },
          "DogodekNaziv": {
            "type": "string"
          },
          "StrankaIme": {
            "type": "string"
          },
          "StrankaPriimek": {
            "type": "string"
          }
        }
      },
      "VstopnicaNova": {
        "type": "object",
        "properties": {
          "DogodekId": {
            "type": "integer"
          },
          "Stranka": {
            "type": "array",
            "items": {
              "$ref": "#/components/schemas/StrankaVnos"
            }
          }
        }
      }
    },
    "responses": {
      "DogodekResponse": {
        "description": "Dogodek Response Object",
        "headers": {
          "Cache-Control": {
            "schema": {
              "type": "string"
            }
          },
          "Access-Control-Allow-Origin": {
            "schema": {
              "type": "string"
            }
          }
        },
        "content": {
          "*/*": {
            "schema": {
              "$ref": "#/components/schemas/DogodekResponse"
            }
          }
        }
      },
      "UserResponse": {
        "description": "User Response Object",
        "headers": {
          "Cache-Control": {
            "schema": {
              "type": "string"
            }
          },
          "Access-Control-Allow-Origin": {
            "schema": {
              "type": "string"
            }
          }
        },
        "content": {
          "*/*": {
            "schema": {
              "$ref": "#/components/schemas/UserResponse"
            }
          }
        }
      }
    },
    "requestBodies": {
      "UserRequest": {
        "description": "An array of new User records",
        "content": {
          "*/*": {
            "schema": {
              "$ref": "#/components/schemas/UserRequest"
            }
          }
        },
        "required": true
      }
    },
    "securitySchemes": {
      "api_key": {
        "type": "apiKey",
        "name": "api_key",
        "in": "header"
      },
      "bearerAuth": {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT"
      }
    }
  },
  "x-original-swagger-version": "2.0"
}